Feel free to Open a Pull Request to share any resources available to the public.
